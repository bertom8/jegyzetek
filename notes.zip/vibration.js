document.getElementById("add").addEventListener ("click", function () {
	navigator.vibrate (200);
});

//navigator.vibrate (200);

//navigator.vibrate ([1000, 2000, 3000]);