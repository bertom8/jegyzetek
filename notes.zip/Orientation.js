window.onload = function () {
    window.screen.mozLockOrientation ("portrait-primary");
};